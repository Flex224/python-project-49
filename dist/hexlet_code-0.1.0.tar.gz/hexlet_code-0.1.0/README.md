### Hexlet tests and linter status:
[![Actions Status](https://github.com/Flex224/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Flex224/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/2dca4dc00118f26e8fc0/maintainability)](https://codeclimate.com/github/Flex224/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/uL4NUW72iSSEdis7Xf4sPVR5u.svg)](https://asciinema.org/a/uL4NUW72iSSEdis7Xf4sPVR5u)